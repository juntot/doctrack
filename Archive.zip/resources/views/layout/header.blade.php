<header>
    <!-- <img src="{{asset('storage/app/public/images/banner1.jpg')}}" alt="banner 1" > -->
</header>