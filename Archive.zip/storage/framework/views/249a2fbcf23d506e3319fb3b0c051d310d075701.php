<nav class="">
  <div class="container d-flex align-items-center">
    <a href="<?php echo e(URL::to('/')); ?>" class="flex-grow-1">
      <img src="<?php echo e(URL::to('/public/img/JarbLogo.png')); ?>" class="comp-logo">
    </a>
    <ul>
      <!-- stff -->
      <?php if(Session::has('auth.email')): ?>
          <li><a href="<?php echo e(URL::to('/')); ?>" class="active home">Home</a></li>
          <?php if(Session::get('auth.type') == "staff"): ?>
          <li><a href="<?php echo e(URL::to('/docs')); ?>">Send Docs</a></li>
          <li><a href="<?php echo e(URL::to('/docs-res')); ?>">Review Docs</a></li>
          <?php elseif(Session::get('auth.type') == "admin"): ?>
          <li><a href="<?php echo e(URL::to('/get-users')); ?>">Users</a></li>
          <li><a href="<?php echo e(URL::to('/get-department')); ?>">Department</a></li>
          <?php else: ?>
          <li><a href="<?php echo e(URL::to('/docs')); ?>">Send Documents</a></li>
          <?php endif; ?>
          <li><a href="#" data-toggle="modal" data-target="#myModalChangePass">Change Pass</a></li>
          <li><a href="<?php echo e(URL::to('/logout')); ?>">Logout</a></li>
          <!-- <li><a href="<?php echo e(URL::to('/login')); ?>">Login</a></li> -->
          <!-- {{ Session::get('error')}} -->
      <?php else: ?>
        <li><a href="<?php echo e(URL::to('/login')); ?>">Login</a></li>
        
      <?php endif; ?>
      <!-- adm -->
      <!-- usr -->
    </ul>
    <!-- <ul class="">
      <li class="flex-grow-1"></li>
      <?php if(Session::has('auth.email')): ?>
          <li><a href="<?php echo e(URL::to('/')); ?>" class="active home">Home</a></li>
          <li><a href="<?php echo e(URL::to('/docs')); ?>">Send Documents</a></li>
          <li><a href="<?php echo e(URL::to('/docs-res')); ?>">Recieved Documents</a></li>
          <li><a href="<?php echo e(URL::to('/logout')); ?>">Logout</a></li>
      <?php else: ?>
        <li><a href="<?php echo e(URL::to('/login')); ?>">Login</a></li>      
      <?php endif; ?>
    </ul> -->
    <div class="mobile-btn">
      <?php if(Session::has('auth.email')): ?>
      <a href="#">
        <div class="mobile-nav"></div>
      </a>
      <?php else: ?>
      <a href="<?php echo e(URL::to('/login')); ?>" style="text-decoration: none; color: var(--accent-gray-color)">Login</a>
      <?php endif; ?>
    </div>
  </div>
</nav>
<?php /**PATH /Users/shitmiming/web/doctrack/resources/views/layout/nav.blade.php ENDPATH**/ ?>