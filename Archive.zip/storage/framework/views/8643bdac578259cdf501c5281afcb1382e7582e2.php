<footer >
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <p>Email: brgyhelpdesk@gmail.com</p>
          <p>Office Hours: 8:00am - 5:00pm</p>
        </div>
        <div class="col-md-6">
            <p class="text-right">Contact #: 0917-123-4567 / 254-8748</p>
            <p class="text-right">Address: Brgy Lahug Cebu City</p>
        </div>
      </div>
    </div>
    <script src="<?php echo e(URL::asset('resources/js/bootstrap/js/jquery3.slim.min.js')); ?>"></script>
    <script>
        function activeNav(){
          let home = true;
            $('nav ul li a').map(function(){
              $(this).removeClass('active');
              if(window.location.href == $(this).attr('href')) {
                $(this).addClass('active');
                home = false;
              }
            });
            if(home){
              $('nav ul li a.home').addClass('active')
            }
        }
        $(function(){
            // set active nav
            activeNav();
        });
    </script>
</footer>
<?php /**PATH /Users/shitmiming/web/bis/resources/views/layout/footer.blade.php ENDPATH**/ ?>