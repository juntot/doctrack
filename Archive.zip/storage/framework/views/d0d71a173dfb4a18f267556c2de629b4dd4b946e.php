<nav>
    <ul class="d-flex container">
      <li class="grow-1"><a href="<?php echo e(URL::to('/')); ?>">LOGO</a></li>
      <li><a href="<?php echo e(URL::to('/')); ?>" class="active home">Home</a></li>
      <li><a href="<?php echo e(URL::to('/contact-us')); ?>">Contact Us</a></li>
      <li><a href="<?php echo e(URL::to('/about')); ?>">About</a></li>
      <li><a href="<?php echo e(URL::to('/login')); ?>">Login-Staff</a></li>
    </ul>
</nav><?php /**PATH /Users/shitmiming/web/bisys/resources/views/layout/nav.blade.php ENDPATH**/ ?>