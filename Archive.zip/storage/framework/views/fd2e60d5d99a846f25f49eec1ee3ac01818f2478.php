<header>
    <!-- <img src="<?php echo e(asset('storage/app/public/images/banner1.jpg')); ?>" alt="banner 1" > -->
</header><?php /**PATH /Users/shitmiming/web/doctrack/resources/views/layout/header.blade.php ENDPATH**/ ?>