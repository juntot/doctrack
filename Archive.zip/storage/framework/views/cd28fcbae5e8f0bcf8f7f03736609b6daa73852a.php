<?php $__env->startSection('seo-meta'); ?>
<title>BIS - about</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<section class="container">
    <div class="row">
      <div class="col-md-4">circ avatar, name, title, hover message</div>
      <div class="col-md-4">circ avatar, name, title, hover message</div>
      <div class="col-md-4">circ avatar, name, title, hover message</div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shitmiming/web/bis/resources/views/about.blade.php ENDPATH**/ ?>