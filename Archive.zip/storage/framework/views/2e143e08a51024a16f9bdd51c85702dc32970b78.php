<?php $__env->startSection('seo-meta'); ?>
<title>BIS - contact-us</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<!-- <div class="banner" style="position: relative; height: 223px;">
  <img src="https://images.unsplash.com/photo-1487611459768-bd414656ea10?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80" alt="" srcset="">
</div> -->
<section class="container">
  <p class="category-name text-bold">We're happy to hear you</p>
  <div class="row">
    <div class="col-md-4">Louisa</div>
    <div class="col-md-4">Anne</div>
    <div class="col-md-4">Steve</div>
  </div>
</section>
<section class="" style="background: #537195">
  <section class="py-3 container">
    <div class="row">
      <div class="col-md-6">
          <form action="/action_page.php">
            <div class="form-group">
              <label for="email">Email address:</label>
              <input type="email" class="form-control" placeholder="Enter email" id="email">
            </div>
            <div class="form-group">
              <label for="pwd">Password:</label>
              <input type="password" class="form-control" placeholder="Enter password" id="pwd">
            </div>
            <div class="form-group form-check">
              <label class="form-check-label">
                <input class="form-check-input" type="checkbox"> Remember me
              </label>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
      </div>
      <div class="col-md-6">
      <i class="fa fa-paper-plane-o" aria-hidden="true"></i>
      </div>
    </div>
  </section>
</section>
<section class="container py-3 mt-3">
    <div class="row">
      <div class="col-12 overflow-hidden">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3925.220466475033!2d123.89637041479705!3d10.324233592629342!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33a9993af2f0ba01%3A0xd9a9ca07162b28e9!2sLahug%20Barangay%20Hall!5e0!3m2!1sen!2sph!4v1638498232488!5m2!1sen!2sph" 
          width="1360" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
      </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shitmiming/web/bis/resources/views/contact-us.blade.php ENDPATH**/ ?>