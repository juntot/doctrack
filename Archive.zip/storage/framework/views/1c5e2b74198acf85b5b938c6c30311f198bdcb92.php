<?php $__env->startSection('seo-meta'); ?>
<title>BIS - home</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
 <!-- header -->
 <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="container">
    <p class="category-name text-bold">Services</p>
    <div class="row">
      <div class="col-md-4">
          <a href="#">
            <div class="thumbnails">
              <img src="<?php echo e(asset('storage/app/public/images/istockphoto-1275746020-170667a.jpeg')); ?>" alt="">
              <div class="caption text-center">Brgy Clearance</div>
            </div>  
          </a>
      </div>
      <div class="col-md-4">
        <a href="#">
          <div class="thumbnails">
            <img src="<?php echo e(asset('storage/app/public/images/istockphoto-1304871532-170667a.jpeg')); ?>" alt="">
            <div class="caption text-center">Cedula</div>
          </div>
        </a>
      </div>
      <div class="col-md-4">
        <a href="#">
          <div class="thumbnails">
            <img src="<?php echo e(asset('storage/app/public/images/istockphoto-1212597557-170667a.jpeg')); ?>" alt="">
            <div class="caption text-center">Brgy Permit</div>
          </div>  
        </a>
      </div>
    </div>
    <p class="category-name text-bold">Activities & Events</p>
    <div class="row">
      <div class="col-md-8">
        <div class="activity-banner">
            <img class="w-100" src="<?php echo e(asset('storage/app/public/images/events.jpg')); ?>" alt="">
        </div>
      </div>
      <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex activity-sched">
                    <div class="activity-date">
                      <span class="text-center">02</span>
                      <span class="text-center">feb</span>
                    </div>
                    <div class="col-lg-12">
                      <span class="activity-title">Wall Climbing</span>    
                      <span class="activity-detail">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Explicabo rerum harum deserunt maxime optio velit, distinctio repudiandae maiores magni ab impedit. Quibusdam voluptatem vitae alias, rerum vel autem. Cumque, assumenda?
                      </span>
                    </div>
                </div>
            </div>
            <div class="col-md-12 mt-3">
                <div class="d-flex activity-sched">
                    <div class="activity-date">
                      <span class="text-center">02</span>
                      <span class="text-center">feb</span>
                    </div>
                    <div class="col-lg-12">
                      <span class="activity-title">Wall Climbing</span>    
                      <span class="activity-detail">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Explicabo rerum harum deserunt maxime optio velit, distinctio repudiandae maiores magni ab impedit. Quibusdam voluptatem vitae alias, rerum vel autem. Cumque, assumenda?
                      </span>
                    </div>
                </div>
            </div>
            <div class="col-md-12 mt-3">
                <div class="d-flex activity-sched">
                    <div class="activity-date">
                      <span class="text-center">02</span>
                      <span class="text-center">feb</span>
                    </div>
                    <div class="col-lg-12">
                      <span class="activity-title">Wall Climbing</span>    
                      <span class="activity-detail">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Explicabo rerum harum deserunt maxime optio velit, distinctio repudiandae maiores magni ab impedit. Quibusdam voluptatem vitae alias, rerum vel autem. Cumque, assumenda?
                      </span>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-3">
              <button class="btn btn-outline-info w-100">View all activies & events</button>
            </div>
        </div>
      </div>
    </div>
</section>
<section class="section-divider text-center text-bold">Latest News & Announcements</section>
<section class="container">
    <div class="row news">
        <div class="col-md-4">
              <div class="row">
                  <div class="col-12">
                    <span class="activity-title">Wanted Teleradyo</span>
                    <div class="activity-detail">
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                    </div>
                  </div>
                  <div class="col-12 mt-3">
                    <span class="activity-title">Wanted Teleradyo</span>
                    <div class="activity-detail">
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                    </div>
                  </div>
                  <div class="col-12 mt-3">
                    <span class="activity-title">Wanted Teleradyo</span>
                    <div class="activity-detail">
                      Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                    </div>
                  </div>
              </div>
              <button class="mt-3 btn btn-outline-info w-100">View all activies & events</button>
        </div>
        <div class="col-md-4">
            <a href="#">
              <div class="news thumbnails">
                <img src="<?php echo e(asset('storage/app/public/images/istockphoto-1275746020-170667a.jpeg')); ?>" alt="">
                <div class="caption text-center">
                  <p class="text-bold">Brgy Volunteers</p>
                  <div class="activity-detail text-left">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi dolore distinctio ullam asperiores ea voluptatem sunt
                  </div>
                </div>
              </div>  
            </a>
        </div>
        <div class="col-md-4">
            <a href="#">
              <div class="news thumbnails">
                <img src="<?php echo e(asset('storage/app/public/images/istockphoto-1275746020-170667a.jpeg')); ?>" alt="">
                <div class="caption text-center">
                  <p class="text-bold">Job Opportunity</p>
                  <div class="activity-detail text-left">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi dolore distinctio ullam asperiores ea voluptatem sunt 
                  </div>
                </div>
              </div>  
            </a>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shitmiming/web/bisys/resources/views/home.blade.php ENDPATH**/ ?>