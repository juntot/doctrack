<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body class="antialiased">
       <article>
            <!-- nav -->
            <?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           
            <!-- main -->
            <?php echo $__env->yieldContent('main'); ?>
            <!-- footer -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </article>
    </body>
</html>
<?php /**PATH /Users/shitmiming/web/bisys/resources/views/layout/main.blade.php ENDPATH**/ ?>